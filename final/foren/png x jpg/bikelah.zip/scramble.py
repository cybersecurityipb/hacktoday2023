from PIL import Image
from random import randint
from struct import unpack
from pwn import xor

image1 = Image.open('flag.jpg')
image2 = Image.new('RGB', (848, 480))

size = 16
index = 0
pixels = 0
for i in range(0, image1.height, size):
	for j in range(image1.width):
		x = index % image2.width
		y = index // image2.width * size
		for a in range(size):
			if i + a < image1.height:
				colour = image1.getpixel((j, i + a))
				image2.putpixel((x, y + a), colour)
				pixels += 1
		index += 1

#image2.save('babyjpg.jpg', 'JPEG')

imageA = Image.new('RGB', (848, 480))
imageB = Image.new('RGB', (848, 480))
imageC = Image.new('RGB', (848, 480))
for i in range(848):
	for j in range(480):
		imageA.putpixel((i, j), (randint(0, 255), randint(0, 255), randint(0, 255)))
		imageB.putpixel((i, j), (randint(0, 255), randint(0, 255), randint(0, 255)))
		imageC.putpixel((i, j), (randint(0, 255), randint(0, 255), randint(0, 255)))

imageAB = Image.new('RGB', (848, 480))
imageBC = Image.new('RGB', (848, 480))
imageAC = Image.new('RGB', (848, 480))
for i in range(848):
	for j in range(480):
		colour = tuple([p ^ q for p, q in zip(imageA.getpixel((i, j)), imageB.getpixel((i, j)))])
		imageAB.putpixel((i, j), colour)
		colour = tuple([p ^ q for p, q in zip(imageB.getpixel((i, j)), imageC.getpixel((i, j)))])
		imageBC.putpixel((i, j), colour)
		colour = tuple([p ^ q for p, q in zip(imageA.getpixel((i, j)), imageC.getpixel((i, j)))])
		imageAC.putpixel((i, j), colour)
		colour = tuple([p ^ q for p, q in zip(image2.getpixel((i, j)), imageAB.getpixel((i, j)))])
		image2.putpixel((i, j), colour)
imageBC.save(str(image1.width)+'.png', 'PNG')
imageAC.save(str(image1.height)+'.png', 'PNG')

image2.save('bikelah.png', 'PNG')

f = open('bikelah.png', 'rb').read()
new = b'\x89PNG\r\n\x1a\n'
i = 8
while i < len(f):
	length = unpack('>I', f[i:i+4])[0]
	key = f[i+8+length:i+8+length+4]
	new = xor(new, key)
	new += f[i:i+8+length]
	i = i+8+length+4
open('bikelah.png', 'wb').write(new)
